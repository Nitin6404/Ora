const Test = () => {
    return (
        <>
        <div className="w-56 h-56 bg-[url('active-program-bg.png')] p-5">
            test hello 
        </div>
        </>
    )
}

export default Test